CONFIG = {
    "name": "AureonOS",
    "version": "0.1.0",
    "theme": "liquid_glass"
}


def load_config():
    return CONFIG.copy()