import os
import sys

from apps.system_info import system_info
from apps.files import files
from apps.settings import settings

from ui.desktop import desktop

from system.filesystem.filesystem import (
    list_directory,
    directory_exists
)

from system.virtualstorage.analyzer import analyze_port

from core.timer import timer


CURRENT_PATH = "/"


def clear():
    os.system("cls")


def normalize_path(current, target):
    if target.startswith("/"):
        path = target
    else:
        if current == "/":
            path = "/" + target
        else:
            path = current.rstrip("/") + "/" + target

    parts = []

    for part in path.split("/"):
        if part == "" or part == ".":
            continue

        if part == "..":
            if parts:
                parts.pop()
        else:
            parts.append(part)

    return "/" + "/".join(parts)


def command_ls():
    items = list_directory(CURRENT_PATH)

    if items is None:
        print("Filesystem error.")
        return

    if not items:
        print("(empty)")
        return

    for item in items:
        if item.endswith(".service"):
            print(f"  {item}")
        else:
            print(f"  {item}/")


def command_cd(target):
    global CURRENT_PATH

    new_path = normalize_path(CURRENT_PATH, target)

    if not directory_exists(new_path):
        print(f"Directory not found: {target}")
        return

    CURRENT_PATH = new_path


def command_pwd():
    print(CURRENT_PATH)


def reload_os():
    print()
    print("Reloading AureonOS...")
    print()

    os.execv(
        sys.executable,
        [sys.executable] + sys.argv
    )


def show_help():
    print()
    print("AureonOS commands")
    print("-----------------")
    print("help       Show commands")
    print("clear      Clear screen")
    print("ls         List virtual files")
    print("cd         Change directory")
    print("pwd        Show current path")
    print("desktop    Show desktop")
    print("files      File manager")
    print("system     System information")
    print("settings   Settings")
    print("analysis   Analyze virtual storage port")
    print("timer      Start a timer")
    print("refresh    Reload AureonOS")
    print("reloadOS   Reload AureonOS")
    print("reboot     Restart AureonOS")
    print("shutdown   Exit AureonOS")


def start_shell():
    global CURRENT_PATH

    clear()
    desktop()

    while True:
        try:
            command_line = input(
                f"\nAureonOS:{CURRENT_PATH} > "
            ).strip()

        except KeyboardInterrupt:
            print()
            continue

        except EOFError:
            break

        if not command_line:
            continue

        parts = command_line.split()

        command = parts[0].lower()
        arguments = parts[1:]

        if command == "help":
            show_help()

        elif command == "clear":
            clear()

        elif command == "ls":
            command_ls()

        elif command == "cd":
            if not arguments:
                command_cd("/")
            else:
                command_cd(arguments[0])

        elif command == "pwd":
            command_pwd()

        elif command == "desktop":
            clear()
            desktop()

        elif command == "files":
            files()

        elif command == "system":
            system_info()

        elif command == "settings":
            settings()

        elif command == "analysis":
            if not arguments:
                print()
                print("Usage:")
                print("  analysis port1")
                print("  analysis port2")
            else:
                analyze_port(arguments[0])

        elif command == "timer":
            if not arguments:
                print()
                print("Usage:")
                print("  TIMER 10:00")
                print("  TIMER 1:00")
                print("  TIMER 1:00:00")
            else:
                timer(arguments[0])

        elif command == "refresh":
            reload_os()

        elif command == "reloados":
            reload_os()

        elif command == "reboot":
            CURRENT_PATH = "/"
            clear()
            desktop()

        elif command == "shutdown":
            print()
            print("Shutting down AureonOS...")
            break

        else:
            print()
            print(f"Unknown command: {command}")
            print("Type 'help' for available commands.")