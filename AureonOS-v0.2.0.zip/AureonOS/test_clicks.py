from ui.input.events import events


def files():
    print("FILES CLICKED!")


def system():
    print("SYSTEM CLICKED!")


events.register_click(
    "files",
    10, 10,
    30, 20,
    files
)

events.register_click(
    "system",
    40, 10,
    60, 20,
    system
)


print("Click en 15,15:")
events.handle_click(15, 15)

print()

print("Click en 50,15:")
events.handle_click(50, 15)

print()

print("Click en 80,15:")
events.handle_click(80, 15)