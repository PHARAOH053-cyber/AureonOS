from ui.themes.liquid_glass import draw_desktop


def desktop():
    draw_desktop()