def widget(title, value):

    print()
    print("╭──────────────────────────────╮")
    print(f"│ {title:<28} │")
    print("├──────────────────────────────┤")
    print(f"│ {value:<28} │")
    print("╰──────────────────────────────╯")