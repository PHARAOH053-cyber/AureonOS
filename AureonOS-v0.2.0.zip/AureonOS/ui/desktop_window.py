import os
import threading
import tkinter as tk
from tkinter import scrolledtext

from PIL import Image, ImageTk

from core.config import load_config, CONFIG, save_config

from ui.wallpapers.wallpaper_manager import (
    get_wallpaper_path,
    get_wallpapers,
    get_next_wallpaper
)


class AureonDesktop:

    def __init__(self, command_callback=None):

        self.command_callback = command_callback

        self.root = tk.Tk()

        self.root.title(
            "AureonOS"
        )

        self.root.attributes(
            "-fullscreen",
            True
        )

        self.root.configure(
            background="black"
        )

        self.wallpaper_image = None
        self.wallpaper_photo = None

        self.create_background()

        self.create_terminal()

        self.root.bind(
            "<F11>",
            self.toggle_fullscreen
        )

        self.root.bind(
            "<Escape>",
            self.exit_fullscreen
        )

        self.root.bind(
            "<Control-Shift-W>",
            self.switch_wallpaper_event
        )

        self.root.after(
            100,
            self.update_wallpaper
        )

    # --------------------------------------------------
    # BACKGROUND
    # --------------------------------------------------

    def create_background(self):

        self.background = tk.Label(
            self.root,
            background="black"
        )

        self.background.place(
            x=0,
            y=0,
            relwidth=1,
            relheight=1
        )

        self.load_wallpaper()

    def load_wallpaper(
        self,
        filename=None
    ):

        config = load_config()

        if filename is None:

            filename = config.get(
                "wallpaper"
            )

        if not filename:

            wallpapers = get_wallpapers()

            if not wallpapers:
                return

            filename = wallpapers[0]

        path = get_wallpaper_path(
            filename
        )

        if not os.path.exists(path):
            return

        try:

            image = Image.open(
                path
            ).convert(
                "RGB"
            )

            self.wallpaper_image = image

            self.render_wallpaper()

        except Exception as error:

            print(
                f"Wallpaper error: {error}"
            )

    def render_wallpaper(self):

        if self.wallpaper_image is None:
            return

        width = self.root.winfo_width()
        height = self.root.winfo_height()

        if width <= 1 or height <= 1:
            return

        image = self.wallpaper_image.copy()

        image_ratio = (
            image.width /
            image.height
        )

        screen_ratio = (
            width /
            height
        )

        if image_ratio > screen_ratio:

            new_height = height

            new_width = int(
                height * image_ratio
            )

        else:

            new_width = width

            new_height = int(
                width / image_ratio
            )

        image = image.resize(
            (
                new_width,
                new_height
            ),
            Image.Resampling.LANCZOS
        )

        left = (
            new_width - width
        ) // 2

        top = (
            new_height - height
        ) // 2

        image = image.crop(
            (
                left,
                top,
                left + width,
                top + height
            )
        )

        self.wallpaper_photo = ImageTk.PhotoImage(
            image
        )

        self.background.configure(
            image=self.wallpaper_photo
        )

    # --------------------------------------------------
    # TERMINAL
    # --------------------------------------------------

    def create_terminal(self):

        self.terminal_frame = tk.Frame(
            self.root,
            bg="#101522",
            bd=0,
            highlightthickness=1,
            highlightbackground="#7896c8"
        )

        self.terminal_frame.place(
            relx=0.5,
            rely=0.5,
            anchor="center",
            relwidth=0.78,
            relheight=0.62
        )

        self.title_bar = tk.Frame(
            self.terminal_frame,
            bg="#151c2b",
            height=42
        )

        self.title_bar.pack(
            fill="x"
        )

        self.title_label = tk.Label(
            self.title_bar,
            text="AureonOS Terminal",
            bg="#151c2b",
            fg="#e8f0ff",
            font=(
                "Segoe UI",
                11,
                "bold"
            )
        )

        self.title_label.pack(
            side="left",
            padx=16,
            pady=10
        )

        self.version_label = tk.Label(
            self.title_bar,
            text="v0.2.0",
            bg="#151c2b",
            fg="#8fa9d6",
            font=(
                "Segoe UI",
                9
            )
        )

        self.version_label.pack(
            side="right",
            padx=16
        )

        self.output = scrolledtext.ScrolledText(
            self.terminal_frame,
            bg="#0d111a",
            fg="#e5edff",
            insertbackground="#ffffff",
            selectbackground="#344b72",
            borderwidth=0,
            highlightthickness=0,
            font=(
                "Consolas",
                11
            ),
            wrap="word"
        )

        self.output.pack(
            fill="both",
            expand=True,
            padx=12,
            pady=(10, 6)
        )

        self.output.insert(
            "end",
            "AureonOS graphical environment\n"
        )

        self.output.insert(
            "end",
            "Liquid Glass Desktop\n"
        )

        self.output.insert(
            "end",
            "Version 0.2.0\n\n"
        )

        self.output.insert(
            "end",
            "Type 'help' for available commands.\n\n"
        )

        self.output.insert(
            "end",
            "AureonOS:/ > "
        )

        self.output.configure(
            state="disabled"
        )

        self.command_entry = tk.Entry(
            self.terminal_frame,
            bg="#151c2b",
            fg="#ffffff",
            insertbackground="#ffffff",
            borderwidth=0,
            highlightthickness=1,
            highlightbackground="#354563",
            font=(
                "Consolas",
                11
            )
        )

        self.command_entry.pack(
            fill="x",
            padx=12,
            pady=(4, 12),
            ipady=8
        )

        self.command_entry.bind(
            "<Return>",
            self.submit_command
        )

        self.command_entry.focus_set()

    # --------------------------------------------------
    # COMMANDS
    # --------------------------------------------------

    def submit_command(
        self,
        event=None
    ):

        command = self.command_entry.get().strip()

        if not command:
            return "break"

        self.command_entry.delete(
            0,
            "end"
        )

        self.write_command(
            command
        )

        if self.command_callback:

            threading.Thread(
                target=self.command_callback,
                args=(command,),
                daemon=True
            ).start()

        return "break"

    def write_command(
        self,
        command
    ):

        self.output.configure(
            state="normal"
        )

        self.output.insert(
            "end",
            command + "\n"
        )

        self.output.configure(
            state="disabled"
        )

        self.output.see(
            "end"
        )

    def write_output(
        self,
        text
    ):

        self.output.configure(
            state="normal"
        )

        self.output.insert(
            "end",
            text
        )

        self.output.configure(
            state="disabled"
        )

        self.output.see(
            "end"
        )

    # --------------------------------------------------
    # WALLPAPER SWITCH
    # --------------------------------------------------

    def switch_wallpaper(self):

        config = load_config()

        current = config.get(
            "wallpaper"
        )

        next_wallpaper = get_next_wallpaper(
            current
        )

        if next_wallpaper is None:
            return

        CONFIG["wallpaper"] = (
            next_wallpaper
        )

        save_config()

        self.load_wallpaper(
            next_wallpaper
        )

        self.write_output(
            "\nWallpaper switched to: "
            + next_wallpaper
            + "\n\nAureonOS:/ > "
        )

    def switch_wallpaper_event(
        self,
        event=None
    ):

        self.switch_wallpaper()

    # --------------------------------------------------
    # WINDOW
    # --------------------------------------------------

    def update_wallpaper(self):

        self.render_wallpaper()

        self.root.after(
            1000,
            self.update_wallpaper
        )

    def toggle_fullscreen(
        self,
        event=None
    ):

        current = self.root.attributes(
            "-fullscreen"
        )

        self.root.attributes(
            "-fullscreen",
            not current
        )

    def exit_fullscreen(
        self,
        event=None
    ):

        self.root.attributes(
            "-fullscreen",
            False
        )

    def run(self):

        self.root.mainloop()