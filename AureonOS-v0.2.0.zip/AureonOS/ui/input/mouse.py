class MouseEvent:
    def __init__(self, x, y, button="left"):
        self.x = x
        self.y = y
        self.button = button

    def __repr__(self):
        return (
            f"MouseEvent("
            f"x={self.x}, "
            f"y={self.y}, "
            f"button={self.button}"
            f")"
        )


class Mouse:
    def __init__(self):
        self.x = 0
        self.y = 0

    def move(self, x, y):
        self.x = x
        self.y = y

    def click(self, button="left"):
        return MouseEvent(
            self.x,
            self.y,
            button
        )


mouse = Mouse()