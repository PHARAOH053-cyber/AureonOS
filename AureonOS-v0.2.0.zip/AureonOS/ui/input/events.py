class EventSystem:

    def __init__(self):
        self.click_targets = []

    def register_click(self, name, x1, y1, x2, y2, action):
        target = {
            "name": name,
            "x1": x1,
            "y1": y1,
            "x2": x2,
            "y2": y2,
            "action": action
        }

        self.click_targets.append(target)

    def handle_click(self, x, y):

        for target in self.click_targets:

            if (
                target["x1"] <= x <= target["x2"]
                and
                target["y1"] <= y <= target["y2"]
            ):
                return target["action"]()

        return False

    def clear(self):
        self.click_targets.clear()


events = EventSystem()