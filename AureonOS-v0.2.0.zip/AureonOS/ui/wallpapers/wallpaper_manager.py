import os

from PIL import Image


WALLPAPER_DIRECTORY = os.path.dirname(__file__)

SUPPORTED_EXTENSIONS = (
    ".png",
    ".jpg",
    ".jpeg",
    ".webp"
)


def get_wallpapers():

    wallpapers = []

    if not os.path.exists(
        WALLPAPER_DIRECTORY
    ):
        return wallpapers

    for filename in os.listdir(
        WALLPAPER_DIRECTORY
    ):

        if filename.lower().endswith(
            SUPPORTED_EXTENSIONS
        ):

            wallpapers.append(
                filename
            )

    wallpapers.sort()

    return wallpapers


def get_wallpaper_path(filename):

    return os.path.join(
        WALLPAPER_DIRECTORY,
        filename
    )


def get_default_wallpaper():

    wallpapers = get_wallpapers()

    if not wallpapers:
        return None

    return wallpapers[0]


def get_next_wallpaper(
    current_wallpaper
):

    wallpapers = get_wallpapers()

    if not wallpapers:
        return None

    if current_wallpaper not in wallpapers:
        return wallpapers[0]

    current_index = wallpapers.index(
        current_wallpaper
    )

    next_index = (
        current_index + 1
    ) % len(wallpapers)

    return wallpapers[next_index]


def wallpaper_exists(filename):

    return filename in get_wallpapers()


def get_wallpaper_size(filename):

    path = get_wallpaper_path(
        filename
    )

    if not os.path.exists(path):
        return None

    try:

        with Image.open(path) as image:
            return image.size

    except Exception:
        return None


def load_wallpaper(filename):

    path = get_wallpaper_path(
        filename
    )

    if not os.path.exists(path):
        return None

    try:

        return Image.open(path).convert(
            "RGB"
        )

    except Exception:
        return None