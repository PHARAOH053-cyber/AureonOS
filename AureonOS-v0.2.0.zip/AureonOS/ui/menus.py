def main_menu():

    print()
    print("╭──────────────────────────────╮")
    print("│        AUREON MENU           │")
    print("├──────────────────────────────┤")
    print("│  1. Files                    │")
    print("│  2. System                   │")
    print("│  3. Settings                 │")
    print("│  4. Terminal                 │")
    print("╰──────────────────────────────╯")