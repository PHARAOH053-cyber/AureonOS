import platform


def system_info():

    print()
    print("╭────────────────────────────────────╮")
    print("│         AUREON SYSTEM INFO         │")
    print("├────────────────────────────────────┤")
    print(f"│ Host     : {platform.node():<20} │")
    print(f"│ OS       : {platform.system():<20} │")
    print(f"│ Release  : {platform.release():<20} │")
    print(f"│ Python   : {platform.python_version():<20} │")
    print("╰────────────────────────────────────╯")