import os


def files():

    print()
    print("╭────────────────────────────────────╮")
    print("│          AUREON FILES              │")
    print("╰────────────────────────────────────╯")

    try:
        current = os.getcwd()

        print()
        print(f"Location: {current}")
        print()

        for item in os.listdir(current):
            print(f"  ├─ {item}")

    except Exception as error:
        print(f"File system error: {error}")