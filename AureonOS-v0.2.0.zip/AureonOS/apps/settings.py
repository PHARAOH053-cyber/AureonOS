def settings():

    print()
    print("╭────────────────────────────────────╮")
    print("│          AUREON SETTINGS           │")
    print("├────────────────────────────────────┤")
    print("│                                    │")
    print("│  Theme: Liquid Glass               │")
    print("│  Version: 0.1.0                    │")
    print("│                                    │")
    print("╰────────────────────────────────────╯")