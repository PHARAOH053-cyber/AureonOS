import json
import os


CONFIG_FILE = os.path.join(
    os.path.dirname(__file__),
    "aureonos_config.json"
)


DEFAULT_CONFIG = {
    "name": "AureonOS",
    "version": "0.2.0",
    "theme": "liquid_glass",
    "wallpaper": "aureon_light.png"
}


CONFIG = DEFAULT_CONFIG.copy()


def load_config():
    global CONFIG

    if os.path.exists(CONFIG_FILE):

        try:
            with open(
                CONFIG_FILE,
                "r",
                encoding="utf-8"
            ) as file:

                saved_config = json.load(file)

                CONFIG.update(
                    saved_config
                )

        except Exception:
            CONFIG = DEFAULT_CONFIG.copy()

    return CONFIG


def save_config():
    try:

        with open(
            CONFIG_FILE,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                CONFIG,
                file,
                indent=4
            )

        return True

    except Exception as error:

        print(
            f"Configuration error: {error}"
        )

        return False