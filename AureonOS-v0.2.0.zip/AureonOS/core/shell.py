import os
import sys
import io
import contextlib

from apps.system_info import system_info
from apps.files import files
from apps.settings import settings

from system.filesystem.filesystem import (
    list_directory,
    directory_exists
)

from system.virtualstorage.analyzer import analyze_port

from core.timer import timer
from core.executor import execute_program
from core.config import load_config

from ui.wallpapers.wallpaper_manager import (
    get_wallpapers,
    get_next_wallpaper
)

from ui.desktop_window import AureonDesktop


CURRENT_PATH = "/"


desktop_window = None


def clear():
    os.system("cls")


def normalize_path(
    current,
    target
):

    if target.startswith("/"):
        path = target

    else:

        if current == "/":
            path = "/" + target

        else:
            path = (
                current.rstrip("/")
                + "/"
                + target
            )

    parts = []

    for part in path.split("/"):

        if part == "" or part == ".":
            continue

        if part == "..":

            if parts:
                parts.pop()

        else:
            parts.append(part)

    return "/" + "/".join(parts)


def command_ls():

    items = list_directory(
        CURRENT_PATH
    )

    if items is None:
        print("Filesystem error.")
        return

    if not items:
        print("(empty)")
        return

    for item in items:

        if item.endswith(
            ".service"
        ):

            print(
                f"  {item}"
            )

        else:

            print(
                f"  {item}/"
            )


def command_cd(target):

    global CURRENT_PATH

    new_path = normalize_path(
        CURRENT_PATH,
        target
    )

    if not directory_exists(
        new_path
    ):

        print(
            f"Directory not found: {target}"
        )

        return

    CURRENT_PATH = new_path


def command_pwd():

    print(
        CURRENT_PATH
    )


def command_version():

    config = load_config()

    print()

    print(
        "╭────────────────────────────────────╮"
    )

    print(
        "│          AUREON VERSION            │"
    )

    print(
        "├────────────────────────────────────┤"
    )

    print(
        f"│ Name    : {config['name']:<24} │"
    )

    print(
        f"│ Version : {config['version']:<24} │"
    )

    print(
        "╰────────────────────────────────────╯"
    )


def command_switch_wallpaper():

    global desktop_window

    if desktop_window is not None:

        desktop_window.switch_wallpaper()

        return

    wallpapers = get_wallpapers()

    if not wallpapers:

        print(
            "No wallpapers available."
        )

        return

    config = load_config()

    current = config.get(
        "wallpaper"
    )

    next_wallpaper = get_next_wallpaper(
        current
    )

    if next_wallpaper is None:

        print(
            "Could not switch wallpaper."
        )

        return

    from core.config import CONFIG, save_config

    CONFIG["wallpaper"] = (
        next_wallpaper
    )

    save_config()

    print()

    print(
        "Wallpaper switched to:"
    )

    print(
        next_wallpaper
    )


def command_wallpaper_list():

    wallpapers = get_wallpapers()

    print()

    if not wallpapers:

        print(
            "No wallpapers available."
        )

        return

    print(
        "╭────────────────────────────────────╮"
    )

    print(
        "│        AUREON WALLPAPERS           │"
    )

    print(
        "├────────────────────────────────────┤"
    )

    for wallpaper in wallpapers:

        print(
            f"│ {wallpaper:<34} │"
        )

    print(
        "╰────────────────────────────────────╯"
    )


def reload_os():

    print()

    print(
        "Reloading AureonOS..."
    )

    print()

    os.execv(
        sys.executable,
        [sys.executable] + sys.argv
    )


def show_help():

    print()

    print(
        "AureonOS commands"
    )

    print(
        "-----------------"
    )

    print(
        "help              Show commands"
    )

    print(
        "clear             Clear screen"
    )

    print(
        "ls                List virtual files"
    )

    print(
        "cd                Change directory"
    )

    print(
        "pwd               Show current path"
    )

    print(
        "desktop           Show desktop"
    )

    print(
        "files             File manager"
    )

    print(
        "system            System information"
    )

    print(
        "settings          Settings"
    )

    print(
        "version           Show AureonOS version"
    )

    print(
        "analysis          Analyze virtual storage"
    )

    print(
        "timer             Start a timer"
    )

    print(
        "wallpapers        List wallpapers"
    )

    print(
        "switchwallpaper   Switch wallpaper"
    )

    print(
        "refresh           Reload AureonOS"
    )

    print(
        "reloadOS          Reload AureonOS"
    )

    print(
        "reboot            Restart AureonOS"
    )

    print(
        "shutdown          Exit AureonOS"
    )

    print()

    print(
        "Programs"
    )

    print(
        "--------"
    )

    print(
        "Type a program name to launch it."
    )


def process_command(
    command_line
):

    global CURRENT_PATH
    global desktop_window

    if not command_line:
        return

    parts = command_line.split()

    command = parts[0].lower()

    arguments = parts[1:]

    output = io.StringIO()

    try:

        with contextlib.redirect_stdout(
            output
        ):

            if command == "help":

                show_help()

            elif command == "clear":

                if desktop_window:
                    desktop_window.output.delete(
                        "1.0",
                        "end"
                    )

            elif command == "ls":

                command_ls()

            elif command == "cd":

                if not arguments:
                    command_cd("/")

                else:
                    command_cd(
                        arguments[0]
                    )

            elif command == "pwd":

                command_pwd()

            elif command == "desktop":

                pass

            elif command == "files":

                files()

            elif command == "system":

                system_info()

            elif command == "settings":

                settings()

            elif command == "version":

                command_version()

            elif command == "analysis":

                if not arguments:

                    print()
                    print("Usage:")
                    print(
                        "  analysis port1"
                    )
                    print(
                        "  analysis port2"
                    )

                else:

                    analyze_port(
                        arguments[0]
                    )

            elif command == "timer":

                if not arguments:

                    print()
                    print("Usage:")
                    print(
                        "  TIMER 10:00"
                    )
                    print(
                        "  TIMER 1:00"
                    )
                    print(
                        "  TIMER 1:00:00"
                    )

                else:

                    timer(
                        arguments[0]
                    )

            elif command == "wallpapers":

                command_wallpaper_list()

            elif command == "switchwallpaper":

                command_switch_wallpaper()

            elif command == "refresh":

                reload_os()

            elif command == "reloados":

                reload_os()

            elif command == "reboot":

                CURRENT_PATH = "/"

                if desktop_window:

                    desktop_window.write_output(
                        "\nRestarting AureonOS...\n"
                    )

            elif command == "shutdown":

                if desktop_window:

                    desktop_window.root.after(
                        100,
                        desktop_window.root.destroy
                    )

                return

            else:

                launched = execute_program(
                    command_line
                )

                if launched:

                    print(
                        f"Launching: {command_line}"
                    )

                else:

                    print(
                        f"Unknown command or program: {command}"
                    )

                    print(
                        "Type 'help' for available commands."
                    )

    except Exception as error:

        print(
            f"Error: {error}"
        )

    text = output.getvalue()

    if desktop_window and text:

        desktop_window.write_output(
            "\n" + text + "\nAureonOS:/ > "
        )


def start_shell():

    global desktop_window

    clear()

    desktop_window = AureonDesktop(
        command_callback=process_command
    )

    desktop_window.run()