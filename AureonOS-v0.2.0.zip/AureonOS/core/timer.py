import time


def parse_time(value):
    parts = value.split(":")

    try:
        if len(parts) == 2:
            minutes = int(parts[0])
            seconds = int(parts[1])

            if seconds >= 60:
                return None

            return minutes * 60 + seconds

        elif len(parts) == 3:
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(parts[2])

            if minutes >= 60 or seconds >= 60:
                return None

            return hours * 3600 + minutes * 60 + seconds

        else:
            return None

    except ValueError:
        return None


def format_time(total_seconds):
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60

    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    return f"{minutes:02d}:{seconds:02d}"


def timer(value):
    total_seconds = parse_time(value)

    if total_seconds is None:
        print()
        print("Invalid time format.")
        print()
        print("Examples:")
        print("  TIMER 10:00")
        print("  TIMER 1:00")
        print("  TIMER 1:00:00")
        return

    if total_seconds <= 0:
        print()
        print("Timer must be greater than 0.")
        return

    print()
    print("╭────────────────────────────────────╮")
    print("│          AUREON TIMER              │")
    print("├────────────────────────────────────┤")
    print(f"│ Time: {format_time(total_seconds):<27} │")
    print("╰────────────────────────────────────╯")
    print()

    try:
        while total_seconds > 0:
            print(
                f"\rTIMER  [{format_time(total_seconds)}]",
                end="",
                flush=True
            )

            time.sleep(1)
            total_seconds -= 1

        print(
            "\rTIMER  [00:00]"
        )

        print()
        print("╭────────────────────────────────────╮")
        print("│          TIMER FINISHED             │")
        print("╰────────────────────────────────────╯")

    except KeyboardInterrupt:
        print()
        print()
        print("Timer cancelled.")