import os
import subprocess


def execute_program(program):
    program = program.strip()

    if not program:
        return False

    try:
        subprocess.Popen(
            [
                "cmd",
                "/c",
                "start",
                "",
                program
            ],
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )

        print()
        print(f"Launching: {program}")
        return True

    except Exception as error:
        print()
        print(f"Could not launch '{program}'.")
        print(f"Error: {error}")
        return False