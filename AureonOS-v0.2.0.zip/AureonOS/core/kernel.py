from core.shell import start_shell
from core.config import load_config


def start_kernel():

    config = load_config()

    print()
    print(
        "Aureon Kernel initialized."
    )

    print(
        f"Theme: {config['theme']}"
    )

    print(
        f"Version: {config['version']}"
    )

    print()

    start_shell()