VIRTUAL_FILESYSTEM = {
    "/": {
        "apps": {},
        "system": {
            "filesystem": {},
            "processes": {},
            "services": {
                "desktop.service": None,
                "shell.service": None,
                "theme.service": None
            }
        },
        "users": {
            "lio": {}
        },
        "config": {}
    }
}


def get_directory(path):
    if path == "/":
        return VIRTUAL_FILESYSTEM["/"]

    parts = [part for part in path.strip("/").split("/") if part]

    current = VIRTUAL_FILESYSTEM["/"]

    for part in parts:
        if part not in current:
            return None

        current = current[part]

    return current


def list_directory(path):
    directory = get_directory(path)

    if directory is None:
        return None

    return list(directory.keys())


def directory_exists(path):
    return get_directory(path) is not None