import os

VIRTUAL_STORAGE_PATH = os.path.join(
    os.path.dirname(__file__),
    "virtualdevices"
)


def get_port_path(port):
    return os.path.join(
        VIRTUAL_STORAGE_PATH,
        port
    )


def print_tree(path, prefix=""):
    try:
        items = sorted(os.listdir(path))
    except PermissionError:
        print(f"{prefix}└── [ACCESS DENIED]")
        return
    except OSError as error:
        print(f"{prefix}└── [ERROR: {error}]")
        return

    for index, item in enumerate(items):
        item_path = os.path.join(path, item)
        is_last = index == len(items) - 1

        if is_last:
            connector = "└── "
            next_prefix = prefix + "    "
        else:
            connector = "├── "
            next_prefix = prefix + "│   "

        if os.path.isdir(item_path):
            print(f"{prefix}{connector}{item}/")
            print_tree(item_path, next_prefix)
        else:
            print(f"{prefix}{connector}{item}")


def analyze_port(port):
    port = port.lower()

    if port not in ("port1", "port2"):
        print()
        print("Unknown virtual storage port.")
        print("Available ports: port1, port2")
        return

    port_path = get_port_path(port)

    print()
    print("╭────────────────────────────────────────────╮")
    print("│        AUREON STORAGE ANALYSIS             │")
    print("├────────────────────────────────────────────┤")
    print(f"│ Port   : {port:<32} │")
    print("├────────────────────────────────────────────┤")

    if not os.path.exists(port_path):
        print("│ Status : NOT FOUND                         │")
        print("╰────────────────────────────────────────────╯")
        return

    items = sorted(os.listdir(port_path))

    if not items:
        print("│ Status : EMPTY                             │")
        print("╰────────────────────────────────────────────╯")
        return

    print("│ Status : CONNECTED                         │")
    print("╰────────────────────────────────────────────╯")
    print()

    for index, item in enumerate(items):
        item_path = os.path.join(port_path, item)
        is_last = index == len(items) - 1

        if is_last:
            connector = "└── "
            prefix = "    "
        else:
            connector = "├── "
            prefix = "│   "

        if os.path.isdir(item_path):
            print(f"{connector}{item}/")
            print_tree(item_path, prefix)
        else:
            print(f"{connector}{item}")