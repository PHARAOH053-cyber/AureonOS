import os
import time

from core.kernel import start_kernel


def clear():
    os.system("cls")


def boot():
    clear()

    print()
    print("====================================================")
    print()
    print("                 A U R E O N O S")
    print()
    print("                    v0.1.0")
    print()
    print("====================================================")
    print()

    print("[ OK ] Aureon Bootloader")
    time.sleep(0.25)

    print("[ OK ] Loading kernel")
    time.sleep(0.25)

    print("[ OK ] Loading services")
    time.sleep(0.25)

    print("[ OK ] Loading user interface")
    time.sleep(0.25)

    print()
    print("AureonOS is starting...")
    time.sleep(0.7)

    start_kernel()