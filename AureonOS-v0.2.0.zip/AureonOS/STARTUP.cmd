@echo off
title AureonOS
cd /d "%~dp0"

python aureonos.py

pause